#include<stdio.h>

int main()
{
	int n=1,k=2;
	do
	{
		k--;
		if(k) continue;
	}while(--n);

	printf("n:%d,   k:%d\n",n,k);
	return 0;
}

