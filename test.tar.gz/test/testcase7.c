#include<stdio.h>

#define LEN 10000

int main()
{
  int i;
  int a[LEN], b[LEN], c[LEN], d[LEN], e[LEN], f[LEN], g[LEN];
  int r1 = 0, r2 = 0, r3 = 0;

  for(i = 0; i < LEN; i++){
    a[i] = b[i] + c[i];
    d[i] = e[i] + f[i];
    g[i] = a[i] + d[i];
    
    r2 += a[i];
    r3 += d[i];
    r1 += g[i];
  }

  printf("%d %d %d\n", r1, r2, r3);

  return (0);
}
