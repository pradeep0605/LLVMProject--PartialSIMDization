#include<stdio.h>
#define LEN 100000


int main()
{
	
	unsigned int s, t = 0, a[LEN],b[LEN],c[LEN];
	for (int i = 0; i < LEN; i++) 
	{
		s = b[i] * c[i];
		a[i] = s + t;
		t = s;
	}
	

	return 0;
}



