#include<iostream>
using namespace std;

class apv
{
public:

	int a,b,c;

	apv()
	{
		a = 2;
		b = 1;
		c = a+b;
	}
	void display()
	{
		cout << "a :" << a << "b:" << b << "c:" << c << endl;
	}

};

int main()
{
	apv var;
	var.display();
return 0;
}

