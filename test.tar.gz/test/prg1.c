#include<stdio.h>
#define LEN 1048576


int main()
{
        unsigned short arr[LEN],brr[LEN]={15,35,5},crr[LEN],res=0;	
        unsigned long long int *ptr, *ptr2, *ptr3;
        unsigned int i=0,j=0;
	for( j=0;j<1024;j++)
	for(i=0;i<LEN;i++)
	{
		arr[i]=brr[i]+crr[i];
		res+=arr[i];
	}

	printf("Result:%u\n",res);
	return 0;
}

