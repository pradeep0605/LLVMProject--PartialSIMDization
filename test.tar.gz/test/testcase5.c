#include<stdio.h>
#define LEN 1000


int main()
{
	unsigned int aa[LEN][LEN],bb[LEN][LEN],cc[LEN][LEN];
	for (int i = 0; i < LEN; i++)
	{
		for (int j = 0; j < LEN; j++) 
		{
			aa[i][j] = aa[i][j] * cc[j][i] + bb[i][j];
		}
	}
	return 0;
}



