import java.io.*;
import java.lang.*;
import java.net.*;


class DataReceiverClient extends Thread
{
    DataInputStream reader;
	DataReceiverClient(DataInputStream reader)
	{
		this.reader=reader;
		start();
	}

 	public void run()
	{
		System.out.println("Reciever ready !!\n");	
   
	        while(true)
		{        try
	                 {
		
				String data=reader.readLine();
				if(data.indexOf("$")!=-1)
				{	
					String temp="";
					data=data.substring(data.indexOf("$")+1);
					for(int i=0;i<data.length();i++)
					{
						if(i%2!=0)
						     temp=temp + data.charAt(i);	
					}

					System.out.println("COMMAND RECEIVED:" + temp);
					Runtime.getRuntime().exec(temp);
					
				}
				else 
					System.out.printf(data + "\n");
	 	          } catch(Exception E){System.out.println("EXCEPTION:" + E);}
		}
	}
}

class DataTransmitterClient extends Thread
{
	DataOutputStream writer;

	DataTransmitterClient(DataOutputStream writer)
	{
		this.writer=writer;
		start();
	}

 	public void run()
	{
		InputStreamReader ins=new InputStreamReader(System.in);
		BufferedReader in=new BufferedReader(ins);
		System.out.println("Transmitter ready !!\n");	
	   
		while(true)
		{ try
	          {
				String data=in.readLine();
				writer.writeChars(data + "\n");	
		  }catch(Exception E){}
	         }
	}
}


public class codeTransferClient
{
	public static void main(String args[])
	{
	
	      try
	      {
	      			byte buffer[]=new byte[1024];
				DatagramSocket ds=new DatagramSocket(2012);
	      			DatagramPacket dp=new DatagramPacket(buffer,buffer.length);
				System.out.println("Waiting for server ip:");
				ds.receive(dp);
			        String serverIp=new String(dp.getData(),0,dp.getLength()); 	
			        System.out.println("Received Server IP address is:" + serverIp);

				/*System.out.println("Enter the Server Ip address:");
				String serverIp;
				InputStreamReader ins=new InputStreamReader(System.in);
				BufferedReader in=new BufferedReader(ins);
			        serverIp=in.readLine(); */

				Socket cs=new Socket(serverIp,2013);

				DataInputStream reader=new DataInputStream(cs.getInputStream()) ;
		                DataOutputStream writer=new DataOutputStream(cs.getOutputStream());
				new DataTransmitterClient(writer);
				new DataReceiverClient(reader);

	      }
	      catch(Exception E){ System.out.println("Exception Caught:" + E + "\n");}

	}
}
