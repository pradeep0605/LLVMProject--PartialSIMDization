#include<stdio.h>
#include<time.h>
#define LEN 1000000000

int main()
{	
	unsigned int a[45]={0}, x;
 	unsigned int i=0,res1=0,res2=0,finalRes=0;
 	clock_t t1,t2;
 	double  T;
 	
 	for(i=0;i<45;i++)
 	{
 		scanf("%d",&a[i]);
	} 	
	
	t1=clock();
 	for(i=0;i<LEN;i++)
 	{
 		a[1] += a[2] + a[3];
 		a[4] += a[5]  + a[6];
 		
 		a[7] += a[1]  + a[8];
 		a[10]+= a[4] + a[9];
 		
 		a[11]+=a[3]   + a[7]; 
 		a[12]+=a[6]   + a[10];
 		
 		a[13]+=a[11]  + a[8];
 		a[14]+=a[12]  + a[9];
 		
 		a[15]+=a[13]  + a[7];
 		a[16]+=a[14]  + a[10];
 		
 		a[17]+=a[15]  + a[19];
 		a[18]+=a[16]  + a[20];
 		
 		a[21]+=a[17]  + a[19];
 		a[22]+=a[18]  + a[20];
 		
 		if(x == 0)
 		{
 			a[15]+=a[7]  + a[7];
 			a[16]+=a[10]  + a[10];
 		
 			a[17]+=a[13]  + a[19];
 			a[18]+=a[14]  + a[20];
 		
 			a[21]+=a[17]  + a[19];
 			a[22]+=a[18]  + a[20];
 		}
 		//second level
 		
 		a[23]+=a[21]  +  a[25];
 		a[24]+=a[22]  +  a[26];
 		
 		a[27]+=a[23]  +  a[29];
 		a[28]+=a[24]  +  a[30];
 		
 		a[31]+= a[27] +  a[25];
 		a[32]+= a[28] +  a[26];
 		
 		a[33]+= a[31] +  a[29];
 		a[34]+= a[32] +  a[30];
 		
 		a[35]+= a[33] +  a[37];
 		a[36]+= a[34] +  a[38];
 		
 		a[39]+= a[35] +  a[41];
 		a[40]+= a[36] +  a[42];
 		
 		a[43]+= a[39] + a[37];
 		a[44]+= a[40] + a[38];
 		
 		
 		res1+=a[43] + a[41];
 		res2+=a[44] + a[42];
 		
 		finalRes+=res1+res2;
 	}
 	t2=clock();	
 	printf("Result:%u\n",finalRes);
 	T=((double)(t2-t1)) / CLOCKS_PER_SEC;
 	printf("time : %g\n",T);
	return 0;
} 
