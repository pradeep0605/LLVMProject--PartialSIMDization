#include<stdio.h>

int main()
{
        unsigned int a,b,c,d,e,f,g;
	printf("Address of 'A': %u\n",&a);
	printf("Address of 'B': %u\n",&b);
	printf("Address of 'C': %u\n",&c);
	printf("Address of 'D': %u\n",&d);
	printf("Address of 'E': %u\n",&e);
	printf("Address of 'F': %u\n",&f);
	printf("Address of 'G': %u\n",&g);
	return 0;
}


