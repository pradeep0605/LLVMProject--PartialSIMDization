#include<stdio.h>
#define LEN 100000


int main()
{
	unsigned int a[LEN],b[LEN],a1,a2,a3,a4,res;

		for (int j = 0; j < LEN; j+=4) 
		{
			a1=a[j]  + b[j];
			a2=a[j+1]+ b[j+1];
			a3=a[j+2]+ b[j+2];
			a4=a[j+3]+ b[j+3];
			
			a1=a1+a3;
			a2=a2+a4;
			res=res+a1+a2;
		}
		printf("%d\n",res);
	return 0;
}


