#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

#define N 10000
#define M 10000

int main (void)
{
  struct timeval start, end;
  unsigned long long stp = 0;
  int i, k;
  unsigned char a, b, c;
  unsigned char *R = malloc (3 * N);
  unsigned char *W = malloc (3 * N);
  unsigned char *x = R;

  for (i = 0; i < 3 * N; i++)
    *x++ = i;

  gettimeofday (&start, NULL);

  for (k = 0; k < M; k++) {
    unsigned char *r = R;
    unsigned char *w = W;

    for (i = 0; i < N; i++) {
      a = *r++;
      b = *r++;
      c = *r++;

      *w++ = 123*a + 321*b + 567*c;
      *w++ = 234*a + 432*b + 987*c;
      *w++ = 345*a + 543*b + 789*c;
    }
  }

  gettimeofday (&end, NULL);
  stp += (end.tv_sec - start.tv_sec) * 1000000;
  stp += end.tv_usec - start.tv_usec;

  fprintf (stdout, "kernel execution time: %18.9f sec\n", (double) stp / 1000000
);

  return W[12]+W[N-12];
}
