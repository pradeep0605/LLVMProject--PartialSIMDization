#include<stdio.h>
#include<stdlib.h>
	
int main()
{
unsigned int a[5],x,i = 0;

scanf("%u",&x);
do
{
	a[1] = x*1*i;
	a[2] = 2*i+x;
	
	if(x < 100)
	{
		a[1] = x+1*(1+i);
		a[2] = x*2*(i+2);
	}
	
	a[3] = a[1] + a[2]*x;
	a[4] = a[2] - a[1]-x;
	i=(i+(rand()%5));
}
while(i<100);
printf("%d %d %d\n",a[3],a[4],2*i);
return 0;
}
		
