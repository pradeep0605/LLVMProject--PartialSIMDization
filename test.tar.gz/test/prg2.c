#include<stdio.h>
#define LEN 1048576
#define UN (unsigned long long int *)


int main()
{
        unsigned short arr[LEN+9],brr[LEN+9]={15,35,5},crr[LEN+9]={15,6,7};
        unsigned long long int *ptr, *ptr2, *ptr3,res;
        unsigned int i=0,j=0;
	ptr=UN arr; ptr2=UN brr; ptr3=UN crr;
        for( j=0;j<1024;j++)
        for(i=0;i<LEN/4;i++)
        {
            ptr[i]=ptr2[i] + ptr3[i];	
	    res+=ptr[i];
        }

        printf("Result:%lld\n",res);
        return 0;
}
													
