if [ $# -lt 1 ]
then
    echo "Usage: \$ $0 [-AV] file.c"
fi

if [ "$1" == "-AV" ]
then
    if [ $# -eq 2 ]
    then
        clang -O3 -mllvm -unroll-allow-partial -mllvm -unroll-runtime -funsafe-math-optimizations -ffast-math -mllvm -vectorize -mllvm -bb-vectorize-aligned-only $2 -o $2_c_av.o
    fi
else
    clang -O3 -mllvm -unroll-allow-partial -mllvm -unroll-runtime -funsafe-math-optimizations -ffast-math $1 -o $1_c.o
fi
