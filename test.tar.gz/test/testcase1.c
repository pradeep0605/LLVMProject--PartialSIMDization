#include<stdio.h>
#define LEN2 1000


int main()
{
	unsigned int i,j, aa[LEN2][LEN2], bb[LEN2][LEN2];
	for (i = 1; i < LEN2; i++) 
	{
		for (j = 0; j < LEN2; j++) 
			aa[i][j] = aa[i-1][j] + bb[i][j];
	}

/*	for (i = 1; i < LEN2; i++) 
		for (j = 0; j < LEN2; j++) 
			printf("%d  ",aa[i][j]);*/
	return 0;
}



