#include<stdio.h>
#define LEN 100000


int main()
{
	unsigned int k=4,a[LEN+4],b[LEN];
	for (int i = 0; i < LEN; i++) 
	 	a[i] = a[i+k] + b[i];
	

	return 0;
}



