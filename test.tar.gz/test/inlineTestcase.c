#include<stdio.h>


int sum(a,b)
int a,b;
{
	return (a+b);
}

int main()
{
	int a,b,c;
	printf("Enter the two number for addition:");
	scanf("%d%d",&a,&b);
        c=sum(a,b);
	printf("The sum of two number is: %d",c);
	return 0;

}
