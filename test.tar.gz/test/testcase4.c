#include<stdio.h>
#define LEN 100000


int main()
{
	
	unsigned int j, k=0, a[LEN],b[LEN],c[LEN],d[LEN];
	j = -1;
	
	for (int i = 0; i < LEN/2; i++) 
	{
		k = j + 1;
		a[i] = b[k] - d[i];
		j = k + 1;
		b[k] = a[i] + c[k];
	}
	

	return 0;
}



