#include<time.h>	//my_timea

clock_t my_timea_t1, my_timea_t2;	//my_timea
double my_timea_t;	//my_timea

#include<stdio.h>
#include<stdlib.h>

#define LEN2 10000
#define MA(x, y) {x = (y *)calloc(LEN2, sizeof(y));}

//#define DEC(x) x[LEN2][LEN2]
#define R(x, i, j) { x[i][j] = (int)random(); }

int main()
{

#if LEN2 < 1000000
  int i, j;
#else
  long int i, j;
#endif

  //int DEC(aa), DEC(bb), DEC(cc);

  int **aa, **bb, **cc;

  MA(aa, int *);
  MA(bb, int *);
  MA(cc, int *);

  for(i = 0; i < LEN2; i++){
    MA(aa[i], int);
    MA(bb[i], int);
    MA(cc[i], int);
    for(j = 0; j < LEN2; j++){
      R(aa, i, j);
      R(bb, i, j);
      R(cc, i, j);
    }
  }


my_timea_t1 = clock();	//my_timea
  for(i = 0; i < LEN2; i++)
    for(j = 0; j < LEN2; j++)
      aa[i][j] = aa[i][j]*cc[j][i] + bb[i][j];
my_timea_t2 = clock();	//my_timea

my_timea_t = (double)(my_timea_t2 - my_timea_t1)/CLOCKS_PER_SEC;	//my_timea
printf("\n--my time analysis--\n%.6gs\n", my_timea_t);	//my_timea


  return (0);
}
